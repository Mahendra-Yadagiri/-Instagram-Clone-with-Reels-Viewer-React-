import React, { useRef } from 'react'
import {Link}from 'react-router-dom'



function LoginForm() {
  let countrySelectRef=useRef();
  return (
    <div className="App">
      <br></br>
      <br></br>
      <br></br>

      <form className="border">
        <div>
          <br></br>
        <div>
          <select ref={countrySelectRef}>
           <optgroup>English
            <option >India</option>
            <option>Canada</option>
            <option>Australia</option>
            <option>Newzland</option>
            </optgroup>
          </select>
          <br></br>
          <br></br>
          
        </div>
       <img src="https://static.vecteezy.com/system/resources/previews/024/170/870/original/instagram-icon-logo-symbol-free-png.png" style={{width:20,position:"fixed",top:"30%",left:"45%",}} alt=""></img>
         <h3 className='font' style={{position:"relative",left:'5%',top:-3, color:"rgba(239, 240, 246, 1)" 
  }}>Instagram</h3>

      <div>
            <label>Email:</label>
            <input type='text' placeholder='Phone number,email or username'></input>
        </div>
         <div>
            <label>Password:</label>
            <input placeholder='Password' type="password"></input>
        </div>
         <div>
            <button  type="button" onClick={()=>{
              setTimeout(() => {
    window.location.href = "https://www.boostfluence.com/free-tools/instagram-reels-viewer";
  }, 2000);
            }
              
            }>Login</button>
            
            
            <div style={{ display: "flex", alignItems: "center", textAlign: "center" }}>
  <hr style={{ flex: 1, border: "none", borderTop: "1px solid #000" }} />
  <span style={{ padding: "0 10px" }}>OR</span>
  <hr style={{ flex: 1, border: "none", borderTop: "1px solid #000" }} />
</div>

        Don't have account ?
        <Link to ={'/SignupForm'}>sign up</Link>
     
        <p>from</p>
        <p style={{position:"relative", bottom:7}}><b>FACEBOOK</b></p>
        </div>
        
        </div>
        </form>
        
    </div>
  )
}

export default LoginForm
