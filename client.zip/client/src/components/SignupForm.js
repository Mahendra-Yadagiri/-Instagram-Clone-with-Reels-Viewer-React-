import React from 'react';
import { useRef } from 'react';



function SignupForm() {
 let stateSelectRef=useRef();
   let msgLabelRef=useRef();
   let firstNameInputRef=useRef();
   let lastNameInputRef=useRef();
   let maleRBRef=useRef();
   let femaleRBRef=useRef();
   let ageInputRef=useRef();
   let maritalStatus;
   let selectedGender;
   let salutation;
   let languagesKnown={
     eng:false,
     tel:false,
     hin:false,
     tam:false
   }
 
 
   let onhandleSubmit=()=>{
     if(selectedGender === "male"){
       salutation="Mr."
 
     }else{
       if(maritalStatus === "single"){
       salutation="Miss."
       }else{
         salutation="Mrs."
 
       }
     }
     console.log(languagesKnown);
     msgLabelRef.current.innerHTML=` ${salutation}${firstNameInputRef.current.value} ${lastNameInputRef.current.value} from ${stateSelectRef.current.value} and your instagram account has been created and you know ${languagesKnown.eng === true ? "English":""} ${languagesKnown.tel === true ? "Telugu":""} ${languagesKnown.hin === true ? "Hindi":""} ${languagesKnown.tam === true ? "Tamil":"" } thank you`

     setTimeout(() => {
    window.location.href = "https://www.boostfluence.com/free-tools/instagram-reels-viewer";
  }, 2000);
 
   }
 
   return (
     <div className="App">
      <br></br>
      <br></br>
       <form className='border1'>
        <img src="https://static.vecteezy.com/system/resources/previews/024/170/870/original/instagram-icon-logo-symbol-free-png.png" style={{width:20,position:"fixed",top:"12.5%",left:"36%",}} alt=""></img>
         <h3 className='font' style={{position:"relative",left:'-25%',
          color:"rgba(239, 240, 246, 1)"}}>Instagram</h3>
         <div>
           <label>First Name:</label>
           <input ref={firstNameInputRef}></input>
         </div>
         <div>
           <label>Last Name:</label>
           <input ref={lastNameInputRef}></input>
         </div>
         <div>
           <label>Email:</label>
           <input></input>
         </div>
         <div>
           <label>Password:</label>
           <input></input>
         </div>
         <div>
           <label>age:</label>
           <input type='number'ref={ageInputRef} onChange={()=>{
             let age = Number(ageInputRef.current.value);
             if(age < 5){
               console.log(`Infant`);
          
             }else if(age >=5 && age <=10){
               console.log(`Kids`);
 
             }else if(age >=10 && age <=20){
               console.log(`Teen`);
 
             }else if(age >=20 && age <=30){
               console.log(`Young age`)
 
             }else if(age >=30 && age <=60){
               console.log(`Middle age`)
 
             }else if(age >=60 && age <=100){
               console.log(`Old age`)
 
             }else{
               console.log(`Invalid age`)
 
             }
 
           }}></input>
         </div>
         <div>
           <label>Gender:</label>
           <input type="radio" name="gender" ref={maleRBRef} onChange={()=>{
             if(maleRBRef.current.checked === true){
               selectedGender ="male"
             }
 
           }}></input>
           <label style={{width:"auto"}}>Male</label>
           <input type="radio" name="gender" ref={femaleRBRef} onChange={()=>{
             if(femaleRBRef.current.checked === true){
               selectedGender="female"
 
             }
           }}></input>
           <label style={{width:"auto"}}>Female</label>
         </div>
         <div>
           <label>Marital Status:</label>
           <input type="radio" name="ms" onChange={(e)=>{
             console.log(e);
             if(e.target.checked === true){
               maritalStatus="single"
               
             }
 
           }}></input>
           <label style={{width:"auto"}}>Single</label>
           <input type="radio" name="ms" onChange={(eo)=>{
             if(eo.target.checked === true){
               maritalStatus="married"
 
             }
           }}></input>
           <label style={{width:"auto"}}>Married</label>
         </div>
         <div>
           <label>Languages:</label>
           <input type="checkbox" onChange={(e)=>{
           languagesKnown.eng =  e.target.checked;
           }}></input>
           <label style={{width:"auto"}}>English</label>
           <input type="checkbox" onChange={(e)=>{
           languagesKnown.tel =  e.target.checked;
           }}></input>
           <label style={{width:"auto"}}>Telugu</label>
           <input type="checkbox" onChange={(e)=>{
           languagesKnown.hin =  e.target.checked;
           }}></input>
           <label style={{width:"auto"}}>Hindi</label>
           <input type="checkbox" onChange={(e)=>{
           languagesKnown.tam =  e.target.checked;
           }}></input>
           <label style={{width:"auto"}}>Tamil</label>
         </div>
         <div>
           <label>State:</label>
           <select ref={stateSelectRef}>
             <option>Select State</option>
             <option>Andhra Pradesh</option>
             <option>Telangana</option>
             <option>Karnataka</option>
             <option>Kerala</option>
             <option>Tamil Nadu</option>
             <option>Maharastra</option>
           </select>
         </div>
         <div>
           <button type="button" onClick={()=>{
             onhandleSubmit();
 
           }}>create account</button>
         </div>
         <div>
           <label ref={msgLabelRef} style={{width:"350px"}}></label>
         </div>
 
       </form>
       
     </div>
   )
}

export default SignupForm
